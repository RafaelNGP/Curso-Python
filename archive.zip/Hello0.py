x = 'Witcher'
print(f'Toss a coin to your {x}!')
print("O' valley of plenty")
print("O' valley of plenty")
print('oooh')
