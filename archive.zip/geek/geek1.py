from math import pi

valorPi = pi


def funcao1(a, b):
    return a + b
