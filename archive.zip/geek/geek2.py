curso = 'Programacao em Python: Essencial'


def funcao2():
    return curso
