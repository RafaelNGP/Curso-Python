x = 7
print(f'x is {x}')
print(type(x))

y = True
print(f'y is {y}')
print(type(y))

z = "String" # '' e ""
print(f'Z is {z}')
print(type(z))

X = 7.0
print(f'X.0 is {X}')
print(type(X))

S = '''
aqui
tem
coragem
'''.upper()
print(f'{S}')

a = 0
b = 1
Space = f'{a} {b}'
print(Space)
