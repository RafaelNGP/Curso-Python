# INT
x = 7
print(f'x is {x}')
print(type(x))
# BOOLEAN
y = True
print(f'y is {y}')
print(type(y))
# '' e "" são iguais
z = "String"
print(f'Z is {z}')
print(type(z))
#FLOAT
X = 7.0
print(f'X.0 is {X}')
print(type(X))