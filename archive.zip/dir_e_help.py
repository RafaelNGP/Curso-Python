"""
Utilitarios Python para auxiliar na programacao

dir -> Apresenta todos os atributos/propriedades e funcoes/metodos disponiveis para determinado tipo de dado ou variavel.

help -> Apresenta a documentacao/como utilizar os atributos/propriedades e funcoes/metodos disponiveis para determinado
tipo de dado ou variavel.
"""
print(dir('geek'))