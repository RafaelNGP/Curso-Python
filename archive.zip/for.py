words = ['one', 'two', 'three', 'four', 'five']

for i in words:
    print(i)
