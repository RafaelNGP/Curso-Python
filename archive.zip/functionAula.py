def function(n):
    print(n)

function(71)
