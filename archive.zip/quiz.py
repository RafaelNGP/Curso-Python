print ('A, B')
print('C')
