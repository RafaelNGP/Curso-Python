def function(n = 1):
    print(n)

function(87)
