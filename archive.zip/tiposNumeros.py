"""
# Tipo Numerico
#
# >>> num = 42
# >>> num
# 42
# >>> num += 2
# >>> num
# 44
# >>> num *= 2
# >>> num
# 88
# >>> type(num)
# <class 'int'>
"""

num = 1000
print(num)

print(num.__add__(8))