def function(n = 1):
    print(n)
    return n * 2

x = function(87)
print(x)
