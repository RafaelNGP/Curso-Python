import platform

print ('This is python version {}'.format(platform.python_version()))
