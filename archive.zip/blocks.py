x = 42
y = 73

if x < y:
    print(f'x < y: x is {x} and y is {y}')
elif x > y:
    print(f'x > y: x is {x} and y is {y}')
else:
    print('theres something wrong')
