x = 'Witcher'
print('Toss a coin to your {}!'.format(x))
