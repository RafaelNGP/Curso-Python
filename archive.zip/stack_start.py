# Try out the Python stack functions

# Create a new empty stack
stack = []

# Push itens onto the stack
stack.append(1)
stack.append(2)
stack.append(3)
stack.append(4)

# Print the stack contents
print(stack)

# pop an item off the stack
stack.pop()
